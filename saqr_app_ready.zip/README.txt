SAQR App ready package for GitHub Actions build. Upload this repo to GitHub and run the workflow in .github/workflows to build debug APK.
Config: flutter_app/lib/config.dart
