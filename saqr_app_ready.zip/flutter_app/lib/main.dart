import 'package:flutter/material.dart';
import 'screens/splash.dart';
void main() => runApp(const SaqrApp());
class SaqrApp extends StatelessWidget { const SaqrApp({super.key}); @override Widget build(BuildContext context){ return MaterialApp(title: 'شبكة الصقر', debugShowCheckedModeBanner:false, theme: ThemeData.dark(), home: const SplashPage()); }}
