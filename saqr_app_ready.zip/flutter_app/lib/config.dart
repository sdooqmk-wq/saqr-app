const String HOTSPOT_URL = 'http://10.0.0.1/login';
const String TEMPLATE_LOGIN_URL = 'http://10.0.0.1/login?card={CODE}';
const String SUPPORT_WA = 'https://wa.me/967780833746';
const bool OPEN_QR_DIRECT_IF_URL = true;
